<?php
//code phân trang ở trang chủ khi load bằng ajax
function devvn_corenavi_ajax($custom_query = null, $paged = 1) {
    global $wp_query, $wp_rewrite;
    if($custom_query) $main_query = $custom_query;
    else $main_query = $wp_query;
    $big = 999999999;
    $total = isset($main_query->max_num_pages)?$main_query->max_num_pages:'';
    if($total > 1) echo '<div class="paginate_links">';
    echo paginate_links( array(
        'base' 		=> trailingslashit( home_url() ) . "{$wp_rewrite->pagination_base}/%#%/",
        'format' 	=> '?paged=%#%',
        'current' 	=> max( 1, $paged ),
        'total' 	=> $total,
        'mid_size'	=> '5',
        'prev_text'    => __('<<','devvn'),
        'next_text'    => __('>>','devvn'),
    ) );
    if($total > 1) echo '</div>';
}

//Ajax load post
add_action( 'wp_ajax_ajax_load_post', 'ajax_load_post_func' );
add_action( 'wp_ajax_nopriv_ajax_load_post', 'ajax_load_post_func' );
function ajax_load_post_func() {
    if ( !wp_verify_nonce( $_REQUEST['nonce'], "ajax_load_post_nonce")) {
        wp_send_json_error('None?');
    }
    $paged = isset($_POST['ajax_paged'])?intval($_POST['ajax_paged']):'';
    if($paged <= 0 || !$paged || !is_numeric($paged)) wp_send_json_error('Paged?');
    $news = new WP_Query(array(
        'post_type'         =>  'post',
        'posts_per_page'    =>  4,
        'paged'             =>  $paged
    ));
    if($news->have_posts()):
        ob_start();
        $max_post_count = $news->post_count;
        ?>
        <div class="home_news_wrap">
            <?php $stt = 1; while ($news->have_posts()):$news->the_post();?>
                <?php if($stt == 1):?><div class="home_news_col1"><?php endif;?>
                <?php if($stt == 2):?><div class="home_news_col2"><?php endif;?>
                    <?php
					$thumb = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), 'thumbnail' );
					$urlThumb = $thumb['0'];
					?>
					<div class="tintuc_box <?php if(has_post_thumbnail()):?>has_post_thumbnail<?php endif;?>">
						<?php if(has_post_thumbnail()):?>
							<div class="tintuc_box_thumb"><a href="<?php the_permalink();?>" title="<?php the_title()?>" style="background: url(<?php echo $urlThumb;?>) no-repeat center center"><?php the_post_thumbnail('thumbnail');?></a></div>
						<?php endif;?>
						<div class="tintuc_box_infor">
							<h3><a href="<?php the_permalink();?>" title="<?php the_title()?>"><?php the_title();?></a></h3>
							<div class="news_infor_cat"><?php the_category(', ');?></div>
							<div class="news_date"><?php echo get_the_date();?></div>
							<div class="news_excerpt"><?php the_excerpt();?></div>
							<a href="<?php echo get_the_permalink();?>" title="<?php the_title();?>" rel="nofollow" class="news_readmore"><?php _e('Xem thêm >>','devvn')?></a>
						</div>
					</div>
                <?php if($stt == 1 || $stt == $max_post_count):?></div><?php endif;?>
            <?php $stt++; endwhile; wp_reset_query();?>
        </div>
        <?php devvn_corenavi_ajax($news,$paged);?>
        <?php $content = ob_get_clean();?>
    <?php else:?>
        <?php wp_send_json_error('No post?');?>
    <?php endif; //End news
    wp_send_json_success($content);
    die();
}

//Thêm script vào theme
add_action( 'wp_enqueue_scripts', 'devvn_enqueue_UseAjaxInWp' );
function devvn_enqueue_UseAjaxInWp(){
    wp_enqueue_script( 'devvn-ajaxload', esc_url( trailingslashit( get_template_directory_uri() ) . 'js/ajax-loadpost.js' ), array( 'jquery' ), '1.0', true );
    $php_array = array(
        'admin_ajax'      => admin_url( 'admin-ajax.php'),
        'load_post_nonce'   =>  wp_create_nonce('ajax_load_post_nonce'),
    );
    wp_localize_script( 'devvn-ajaxload', 'devvn_array', $php_array );
}