<?php
$news = new WP_Query(array(
	'post_type'         =>  'post',
	'posts_per_page'    =>  4
));
if($news->have_posts()):
$max_post_count = $news->post_count;
?>
<div class="home_tintuc">
	<div class="container">
		<div class="home_news_main">
			<div class="home_news_wrap">
				<?php $stt = 1; while ($news->have_posts()):$news->the_post();?>
					<?php if($stt == 1):?><div class="home_news_col1"><?php endif;?>
					<?php if($stt == 2):?><div class="home_news_col2"><?php endif;?>
						<?php
						$thumb = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), 'thumbnail' );
						$urlThumb = $thumb['0'];
						?>
						<div class="tintuc_box <?php if(has_post_thumbnail()):?>has_post_thumbnail<?php endif;?>">
							<?php if(has_post_thumbnail()):?>
								<div class="tintuc_box_thumb"><a href="<?php the_permalink();?>" title="<?php the_title()?>" style="background: url(<?php echo $urlThumb;?>) no-repeat center center"><?php the_post_thumbnail('thumbnail');?></a></div>
							<?php endif;?>
							<div class="tintuc_box_infor">
								<h3><a href="<?php the_permalink();?>" title="<?php the_title()?>"><?php the_title();?></a></h3>
								<div class="news_infor_cat"><?php the_category(', ');?></div>
								<div class="news_date"><?php echo get_the_date();?></div>
								<div class="news_excerpt"><?php the_excerpt();?></div>
								<a href="<?php echo get_the_permalink();?>" title="<?php the_title();?>" rel="nofollow" class="news_readmore"><?php _e('Xem thêm >>','devvn')?></a>
							</div>
						</div>
					<?php if($stt == 1 || $stt == $max_post_count):?></div><?php endif;?>
				<?php $stt++; endwhile;?>
			</div>
			<?php devvn_corenavi_ajax($news);?>
		</div>
	</div>
</div>
<?php endif; wp_reset_query();//End news?>