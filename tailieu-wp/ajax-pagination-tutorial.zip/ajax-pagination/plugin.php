<?php

	/*
	Plugin Name: AJAX Pagination
	Description: Phân trang website bằng AJAX
	Version: 1.0
	Author: Thach Pham
	Author URI: http://thachpham.com
	*/


/*
 @ ajax_pagination_scripts()
 @ Nhúng file ajax-pagination.js vào theme
 */
 add_action( 'wp_enqueue_scripts', 'ajax_pagination_scripts' );
 function ajax_pagination_scripts() {
 	/*
 	 * Chèn file ajax-pagination.js vào frontend
 	 */
 	wp_enqueue_script( 'ajax-pagination-script', plugins_url( '/ajax-pagination.js', __FILE__ ),
 		array( 'jquery' )
 	);

 	/*
 	 * Gọi AJAX trong WordPress
 	 */
 	global $wp_query;
 	wp_localize_script( 'ajax-pagination-script', 'ajax_object', array(

 		// Các phương thức sẽ sử dụng
		'ajax_url' => admin_url( 'admin-ajax.php' ),
		'query_vars' => json_encode( $wp_query->query )

	));
 }



/*
 @ Hàm chứa dữ liệu trả về
 */
add_action( 'wp_ajax_nopriv_ajax_pagination_data', 'set_ajax_pagination_data' );
add_action( 'wp_ajax_ajax_pagination_data', 'set_ajax_pagination_data' );
function set_ajax_pagination_data() {

    $query_vars = json_decode( stripslashes( $_POST['query_vars'] ), true );

    $query_vars['paged'] = $_POST['page'];


    $posts = new WP_Query( $query_vars );
    $GLOBALS['wp_query'] = $posts;


    if( ! $posts->have_posts() ) { 
        get_template_part( 'content', 'none' );
    }
    else {
        while ( $posts->have_posts() ) { 
            $posts->the_post();
            get_template_part( 'content', get_post_format() );
        }
    }

    the_posts_pagination( array(
    	'mid_size' => 5,
        'prev_text'          => __( 'Previous page', 'twentyfifteen' ),
        'next_text'          => __( 'Next page', 'twentyfifteen' ),
        'before_page_number' => '<span class="meta-nav screen-reader-text">' . __( 'Page', 'twentyfifteen' ) . ' </span>',
    ) );

    die();	

}