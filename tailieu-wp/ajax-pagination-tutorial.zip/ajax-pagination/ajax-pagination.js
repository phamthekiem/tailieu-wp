// chắc chắn là đang sử dụng chế độ No Conflict của jQuery, sử dụng jQuery() thay vì $()
jQuery.noConflict();

// load sau khi website được tải xong
jQuery( document ).ready( function($) {

	/*
	 @ hàm xác định số trang sẽ được tải
	 @ bằng cách bóc tách số trong chuỗi dữ liệu
	 */
	function set_page( element ) {
		element.find('span').remove();
		return parseInt( element.html() );
	}

	$(document).on ( 'click', '.nav-links a', function( event ) {
		event.preventDefault();
		page = set_page( $(this).clone() );

		// AJAX
		$.ajax({
			url: ajax_object.ajax_url,
			type: 'post',
			data: {
				action: 'ajax_pagination_data',
				query_vars: ajax_object.query_vars,
				page: page
			},
			beforeSend: function() {
				/*
				 @ Tạo các hiệu ứng trước khi request gửi đi
				 */
				$( '#main' ).find( 'article' ).remove();
				$( '#main nav' ).remove();
				$( '#main' ).scrollTop(0);
				$( '#main' ).append( '<div id="loading">Đang lấy dữ liệu bài viết</div>' );
			},
			success: function( ketqua ) {
				/*
				 @ Xóa nút loading
				 @ và khôi phục lại dữ liệu trả về
				 */
				$( '#main' ).find( '#loading' ).remove();
				$( '#main' ).append( ketqua );
				console.log(page);

			}

		})
	} ) // end event

} );